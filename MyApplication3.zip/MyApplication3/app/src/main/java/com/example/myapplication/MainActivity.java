package com.example.myapplication;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import static java.lang.Thread.sleep;

public class MainActivity extends AppCompatActivity {

    ListView lvrest;
    ArrayList<HashMap<String, String>> monthlyexpenses;
    Spinner sploc;
    EditText  incomeED, outcomeED, totalED;
    Button btnreset, btnsave, btnupdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lvrest = findViewById(R.id.listviewRest);
        sploc = findViewById(R.id.spinner);
        incomeED = findViewById(R.id.txtname2);
        outcomeED = findViewById(R.id.txtname3);
        totalED = findViewById(R.id.txtname4);
        btnreset = findViewById(R.id.button4);
        btnsave = findViewById(R.id.button3);
        btnupdate = findViewById(R.id.button);
        monthlyexpenses = new ArrayList<>();
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        lvrest.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putString("income", monthlyexpenses.get(position).get("income"));
                bundle.putString("outcome", monthlyexpenses.get(position).get("outcome"));
                bundle.putString("total", monthlyexpenses.get(position).get("total"));
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}