package com.example.myapplication;

public class User {
    String name,phone,email,password,location;
    User(String n, String ph, String em, String pa, String lo){
        name = n;
        phone= ph;
        email = em;
        password = pa;
        location = lo;
    }
}
